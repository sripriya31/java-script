//example1

const user=()=>console.log("Hello world!!");
user();

//example2

const usr=(num)=>console.log(num*num);
usr(25);

//example3

const example = ( x, y, z ) => {
    console.log( x + y + z )
}
  
example( 10, 20, 30 );

