
//example1

const numbers = [1, 2, 3];

const [first, second, third] = numbers;

console.log(first); 
console.log(second); 
console.log(third); 

//example2

let person={
    name:'sri',
    age:19,
    mail:'priya@gmail.com'
}
const{name,age,mail}=person;
console.log(mail);
