//example1

const data=10;
c=data*10;
console.log(c);

//example2

const a=[4,8,12,16,20];
console.log(a);
console.log(a[1]);