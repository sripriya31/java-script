//example1

const arr=[1,2,3,4,5];
for(const a of arr){
    console.log(a);
}

//example2

const name = "sripriya";

for (const char of name) {
  console.log(char);
}

//example3

const languages = ['C language', 'python', 'java','C++','java script'];

for (const lang of languages) {
  console.log(lang);
}
