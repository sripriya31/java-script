//example1

function user(name,...age){
    console.log(name+":"+age);
}
user('sri',19,'priya@gmail.com')

//example2

function sum(...num) {
    let total = 0;
    for (const number of num) {
        total += number;
    }
  return total;
  }
  
  console.log(sum(1, 2, 3)); 
  console.log(sum(4, 5, 6, 7)); 
  