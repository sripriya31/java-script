//example1

let data=[3,6,9,12,15];
console.log(data);

//example2

let name1="sri",name2="priya";
console.log(name1+name2);
