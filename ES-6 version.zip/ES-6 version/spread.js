
//example1

let arr1=[1,2,3];
let arr2=[4,5,6];
let arr3=[...arr1,...arr2];
console.log(arr3);

//example2

function multiply(a, b, c) {
    return a * b * c;
  }
  
  const values = [2, 3, 4];
  const result = multiply(...values);
  
  console.log(result); 

  
