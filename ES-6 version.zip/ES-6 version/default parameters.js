
//example1

function user(name,age=20){
    console.log(name+""+age)
}
user('sri')

//example2

function fun(name = "Guest", message = "Hello") {
    console.log(`${message}, ${name}!`);
  }
  
  fun(); 
   
  
  
  
  
  