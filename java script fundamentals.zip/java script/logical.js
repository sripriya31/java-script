var a =20;
var b=10;
//and
console.log(b<4&&a>15);
//or
console.log(a==20||b==10);
//not
console.log(!(a==b));