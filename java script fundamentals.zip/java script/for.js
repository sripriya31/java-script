// program to print the page no's up to 10 using for loop
for(a=1;a<=10;a++)
{
    console.log("the page no is" + a);
}