var a =100;
var b=2;
console.log(typeof a);
console.log(typeof b);
//addition
console.log(a+b);
//subtraction
console.log(a-b);
//multiplication
console.log(a*b);
//division
console.log(a/b);
//modulus
console.log(a%b);
//exponential
console.log(a**b);
