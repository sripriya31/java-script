var name1='sripriya',name2 = 'teja', name3 ='deepu';
console.log(name1);
console.log(name2);
console.log(name3);

