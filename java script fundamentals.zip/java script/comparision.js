var a=9;
var b=8;
//equal to
console.log(a==b);
//not equal to
console.log(a!=b);
//greater than
console.log(b>a);
//less than
console.log(b<a);


var c=5;
var d='5';
//equal type
console.log(c===d);
//not equal type
console.log(c!==d);