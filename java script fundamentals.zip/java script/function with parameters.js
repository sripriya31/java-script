//function with parameters
function usr(num){
    num1=num*num;
    console.log(num1);
}
usr(25);
