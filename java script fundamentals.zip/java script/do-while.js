// program to print the statement until the condition satisfied using do-while 
var num=1;
do {
    console.log("i am from centurion university");
    num++;
} while(num<=5)