// program to check the grades based on marks using if-else ladder
var marks=40;
if(marks>80)
{
    console.log("Grade A");
}
else if(marks>55)
{
    console.log("Grade B");
}
else
{
    console.log("Grade C");
}