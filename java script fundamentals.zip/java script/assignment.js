var a=2;
var b=5;
a+=1;
b-=1;
a*=2;
b/=2;
console.log(a);
console.log(b);