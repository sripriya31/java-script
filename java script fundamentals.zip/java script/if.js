//program to check the eligibility criteria to vote using if statement
var age=20;
if(age>18)
{
    console.log("you are eligible to vote");
}