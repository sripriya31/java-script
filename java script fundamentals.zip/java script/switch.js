// program to check the values using switch conditional statement
var a=10,b=20,c;
 switch(c)
 {
    case a:console.log("value is 10");
    break;
    case b:console.log("value is 20");
    break;
    default:console.log("no value is selected");
 }