//function return
function greet(){
    return "hello world"
}
let str=greet();
console.log(str);