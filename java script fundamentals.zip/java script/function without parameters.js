//function without parameters
function user(){
    console.log("i am from centurion university");
}
user();


