//numbers
var n =2;
console.log(typeof n);
//string
var a= "sripriya";
console.log(typeof a);
//boolean
var x =true;
console.log(typeof x);
//undefined
var u;
console.log(typeof u);
