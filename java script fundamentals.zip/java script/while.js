// program to print the a value until the given condition satisfied using while loop
let a=1;
while(a<5)
{
    console.log("a =" + a);
    a++;
}