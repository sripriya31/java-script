// program to check the result of the exam using if-else 
var marks=50;
if(marks>35)
{
    console.log("you cleared the exam");
}
else
{
    console.log("you failed the exam");
}