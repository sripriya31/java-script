//example1 

var data=[50,100,150,200,250,300];
var usr=data.every(
    function(element){
        return element<400;
    }
)
console.log(usr);

//example2

var data=[50,100,150,200,250,300];
var ele=data.every(
    function(abc){
        return abc<250;
    }
)
console.log(ele);
