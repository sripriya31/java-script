//example1

let data=["sri","priya",1,2,3];
console.log(Array.isArray(data));

//example2

let a=4;
console.log(Array.isArray(a));

//example3

let arr=[2,4,6,8];
console.log(Array.isArray(arr));
