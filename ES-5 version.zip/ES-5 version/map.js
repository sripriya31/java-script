//example1

var data=[2,4,6,8];
var user=data.map(
    function(element){
        return element*10;
    }
)
console.log(user);

//example2

var arr=[50,100,150,200,250,300];
var usr=arr.map(
    function(ele){
        return ele/10;
    }
)
console.log(usr);