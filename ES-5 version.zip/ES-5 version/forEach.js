//example1

var data=["priya","teja","koushi","deepu","dhanya","chandini","monika"];
data.forEach(
    function (element){
        
        console.log(element);

    
    }
)

//example2

var usr=[1,2,3,4,5];
usr.forEach(
    function(ele){
        console.log(ele);
    }
)