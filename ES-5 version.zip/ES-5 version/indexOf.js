//example1

var data=[5,10,15,20,25,30];
console.log(data.indexOf(25));

//example2

var a=[1,2,3,4,5,2,9,10];
console.log(a.indexOf(2));

//example3

var b=["sri","priya","indu"];
console.log(b.indexOf("priya"));