//example1

var data=[5,7,10,4,7,20,7,5,70];
console.log(data.lastIndexOf(7));

//example2

var a=[1,2,3,4,6,3,5,7,8];
console.log(a.lastIndexOf(3));

//example3

var b=["sri","mythri","teja","jyo","sri","priya"];
console.log(b.lastIndexOf("sri"));